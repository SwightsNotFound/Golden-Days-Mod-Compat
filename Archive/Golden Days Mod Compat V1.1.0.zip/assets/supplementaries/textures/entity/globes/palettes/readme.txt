Here you can put custom colors that will be assigned to each globe depending on the dimension where its placed.
The dimension which will be assigned to it depends on the path of the texture itself which should match its dimension id.
For example, you can use twilight_forest.twilight_forest.png (use . instead of : for modded ones), not needed for vanillas

The texture itself will have to contain an array of colors which will be mapped in order to each of the globe "biomes" as follors.
Colors are read from left to right then from top to bottom

Following are the virtual biomes that each index is associated with:
 - 0: none
 - 1: water light
 - 2: water medium
 - 3: water dark
 - 4: coast/taiga
 - 5: forest
 - 6: plains
 - 7: savanna
 - 8: desert
 - 9: snow
 - 10: ice
 - 11: iceberg/island
 - 12: mushroom island